﻿namespace BLL.EmployeeService;

using BOL.Employee;

public class EmployeeService
{
    public Static List<Employee> GetAllEmployee(){
        List<Employee> elist=DBManager.GetAllEmployee();
        this.ViewData["Employee_lists"]=elist;
        return elist;
    }
    
    public Static bool UpdateEmployee(int Id,String EmpName,String EmailID,String EmpMobile){
        Employee emp=DBManager.EditEmployee(Id,EmpName,EmailID,EmpMobile);
        this.ViewData["particular_id"]=emp;
        return true;
    }

    public Static bool AddEmployee(int Id,String EmpName,String EmailID,String EmpMobile){
        Employee emp=DBManager.AddEmployee(Id,EmpName,EmailID,EmpMobile);
        this.ViewData["particular_id"]=emp;
        return true;
    }

    public Static bool DeleteEmployee(int Id){
        Employee emp=DBManager.DeleteEmployee(Id);
        this.ViewData["particular_id"]=emp;
        return true;
    }
}
