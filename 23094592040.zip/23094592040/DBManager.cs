﻿namespace DAL.DBManager;

using MySql.Data.MySqlClient;

public class DBManager
{
     static String connectString="server=192.168.10.150;port=3306;user=dac39;password=welcome;database=dac39";

      public static List<Employee> GetAllEmployee(){
            List<Employee> elist =new List<Employee>();

            MySqlConnection conn=new MySqlConnection();
            
            conn.ConnectionString=connectString;

            String selQuery="select * from Employee";

            MySqlCommand command=new MySqlCommand(selQuery,conn);

            try{
                conn.Open();
                MySqlDataReader reader=command.ExecuteReader();
                while(reader.Read()){
                    int id=int.Parse(reader["Id"].ToString());
                    String Name=reader["EmpName"].ToString();
                    String Email=reader["EmailID"].ToString();
                    String ContactNumber=reader["EmpMobile"].ToString();

                    Employee emp=new Employee{EmpId=id,EmpName=Name,Email=Email,ContactNumber=ContactNumber};
                    elist.Add(emp);
                }
               reader.Close();
            }catch{
                Console.WriteLine(e.Message);
            }finnally{
                conn.Close();
            }

          return elist;
      }


      public static bool EditEmployee(int Id,String EmpName,String EmailID,String EmpMobile){
            Employee emp =new Employee();

            MySqlConnection conn=new MySqlConnection();
            
            conn.ConnectionString=connectString;

            String upQuery="update Employee set EmpName=@EmpName, EmailID=@EmailID,EmpMobile=@EmpMobile where Id=@Id";

            MySqlCommand command=new MySqlCommand(upQuery,conn);
            command.Parameters.AddWithValues("@EmpName",EmpName);
             command.Parameters.AddWithValues("@EmailID",EmailID);
              command.Parameters.AddWithValues("@EmpMobile",EmpMobile);
               command.Parameters.AddWithValues("@Id",Id);
            try{
                conn.Open();
                if(emp.Id==Id){
                    command.ExecuteNonQuery();
                }
                
                return true;
                }

            }catch{
                Console.WriteLine(e.Message);
            }finnally{
                conn.Close();
            }

          return false;
      }

      public static bool AddEmployee(int Id,String EmpName,String EmailID,String EmpMobile){
            Employee emp =new Employee();

            MySqlConnection conn=new MySqlConnection();
            
            conn.ConnectionString=connectString;

            String deQuery="insert into Employee values Id=@Id,EmpName=@EmpName, EmailID=@EmailID,EmpMobile=@EmpMobile ";

            MySqlCommand command=new MySqlCommand(deQuery,conn);
            command.Parameters.AddWithValues("@EmpName",EmpName);
             command.Parameters.AddWithValues("@EmailID",EmailID);
              command.Parameters.AddWithValues("@EmpMobile",EmpMobile);
               command.Parameters.AddWithValues("@Id",Id);
            try{
                conn.Open();
                command.ExecuteNonQuery();
                return true;
                }

            }catch{
                Console.WriteLine(e.Message);
            }finnally{
                conn.Close();
            }

          return false;
      }

    public static bool DeleteEmployee(int Id){
            Employee emp =new Employee();

            MySqlConnection conn=new MySqlConnection();
            
            conn.ConnectionString=connectString;

            String deQuery="delete from  Employee where Id=@Id";

            MySqlCommand command=new MySqlCommand(deQuery,conn);
            
               command.Parameters.AddWithValues("@Id",Id);
            try{
                conn.Open();
                if(emp.ID==ID){
                      command.ExecuteNonQuery();
                }
                
                return true;
                }

            }catch{
                Console.WriteLine(e.Message);
            }finnally{
                conn.Close();
            }

          return false;
      }
}
