﻿namespace BOL.Employee;

public class Employee
{
      public int EmpId{get;set;}
      public String EmpName{set;get;}
      public String Email{set;get;}
      public String ContactNumber{set;get;}
}
