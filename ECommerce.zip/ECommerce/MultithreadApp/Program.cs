﻿using System;
using Util;
 
Console.WriteLine(Helper.StoreData());
Helper.GetRemoteData();
Console.WriteLine("Hello World!");