﻿using Core.Repositories.Interfaces;

namespace Core.Services.Interfaces
{
    public interface IFlowerService : IFlowerRepository { 
        
    }
}
