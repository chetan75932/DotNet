﻿using Core.Repositories.Interfaces;

namespace Core.Services.Interfaces
{
    public interface IFruitService : IFruitRepository { }
}
