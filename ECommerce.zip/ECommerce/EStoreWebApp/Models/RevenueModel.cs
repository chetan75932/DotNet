namespace EStoreWebApp.Models;
 public class RevenueModel{
        public string Name { get; set; }  
        public int RevenueYear2020 { get; set; }  
        public int RevenueYear2010 { get; set; }  
        public int RevenueYear2000 { get; set; }  
        public int RevenueYear1990 { get; set; }  
}

    