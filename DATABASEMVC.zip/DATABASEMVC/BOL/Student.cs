namespace BOL.student;


public class Student{

    public int ID{get;set;}
    public String First_name{get;set;}
    public String Last_name{get;set;}
}